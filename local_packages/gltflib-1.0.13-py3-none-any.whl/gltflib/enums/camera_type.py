from enum import Enum


class CameraType(Enum):
    PERSPECTIVE = 'perspective'
    ORTHOGRAPHIC = 'orthographic'
