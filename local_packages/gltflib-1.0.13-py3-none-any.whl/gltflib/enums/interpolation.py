from enum import Enum


class Interpolation(Enum):
    LINEAR = 'LINEAR'
    STEP = 'STEP'
    CUBICSPLINE = 'CUBICSPLINE'
