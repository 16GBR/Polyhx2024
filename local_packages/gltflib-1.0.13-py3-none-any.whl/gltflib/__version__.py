VERSION = (1, 0, 13)

__version__ = '.'.join(map(str, VERSION))
